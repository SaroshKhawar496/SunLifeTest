import { LightningElement, track } from "lwc";
import getFinanItems from "@salesforce/apex/FinancialController.getFinanItems";
import findAccount from "@salesforce/apex/FinancialController.findAccount";
import { NavigationMixin } from "lightning/navigation";

export default class FinancialActsComp extends NavigationMixin(
  LightningElement
) {
  @track columns = "";
  @track data = "";
  @track sortBy = "";
  @track sortDir;

  connectedCallback() {
    const actions = [
      { label: "View", name: "view" },
      { label: "Edit", name: "edit" }
    ];
    this.columns = [
      {label: 'Id', fieldName: 'Actid'},
      {
        
        label: "Account Name",
        fieldName: "ActName",
        type: "text",
        sortable: "true"
       },
      {
        label: "Account Owner",
        fieldName: "ActOwner",
        type: "text",
        sortable: "true"
      },
      { label: "Phone", fieldName: "Phone", type: "text" },
      {
        label: "Website",
        fieldName: "Website",
        type: "text"
      },
      {
        label: "Annual Revenue",
        fieldName: "Revenue",
        type: "currency"
      },
      {
        type: "action",
        typeAttributes: { rowActions: actions }
      }
    ];
    this.getData();
  }

  getData() {
    getFinanItems()
      .then((result) => {
        console.log(JSON.parse(result));
        this.data = JSON.parse(result);
      })
      .catch((err) => {
        console.log("Error");
      });
  }
  handleSort(event) {
    this.sortBy = event.detail.fieldName;
    this.sortDir = event.detail.sortDirection;
    this.sortData(this.sortBy, this.sortDir);
  }

  sortData(fieldname, direction) {
    console.log("this.data: ", this.data);
    let str = JSON.stringify(this.data);
    console.log("stringify this.data: ", str);
    console.log("parsed data: ", JSON.parse(str));

    let parseData = JSON.parse(JSON.stringify(this.data));
    // Return the value stored in the field
    let keyValue = (a) => {
      console.log( ' a[fieldname]: ', a[fieldname]);
      return a[fieldname];
    };
    // cheking reverse direction
    let isReverse = direction === "asc" ? 1 : -1;
    console.log('isReverse: ', isReverse);
    // sorting data
    parseData.sort((x, y) => {
      console.log('x: ', x);
      console.log('y: ', y);
      x = keyValue(x) ? keyValue(x) : ""; // handling null values
      y = keyValue(y) ? keyValue(y) : "";
      // sorting values based on direction
      return isReverse * ((x > y) - (y > x));
    });
    this.data = parseData;
  }

  searchAccount(event) {
    let inputAct = event.target.value;
    console.log("actName: ", inputAct);
    if (inputAct != null) {
      findAccount({ inputAct })
        .then((result) => {
          console.log("result: ", result);

          this.data = JSON.parse(result);
        })
        .catch((error) => {
          console.log("error: ", error);
        });
    }
  }

  handleRowAction(event) {
    console.log("event.detail.action.name: ", event.detail.action.name);
    let action = event.detail.action.name;

    console.log("event.detail.row.Actid: ", event.detail.row.Actid);
    
    const row = event.detail.row;
    

    if (action === "view") {
      this[NavigationMixin.GenerateUrl]({
        type: "standard__recordPage",
        attributes: {
          recordId: row.Actid,
          actionName: "view"
        }
      }).then(url =>{
        window.open(url, '_blank');
      })
    }
    if (action === "edit") {
      this[NavigationMixin.Navigate]({
        type: "standard__recordPage",
        attributes: {
          recordId: row.Actid,
          actionName: "edit"
        }
      });
    }

  }
}
